## Usage

```
python ./cluster.py spawnpoints.json -os spawnpoints.compressed.json -r 70 -t 180
```

Clusters all spawnpoints in `spawnpoints.json` within 70 meters of eachother and within 180 seconds of spawn time and saves the output to `spawnpoints.compressed.json`

