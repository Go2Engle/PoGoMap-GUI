# halpmepl0x
# for those that messaged me with "i'm on dev, example.py dont work"
# thunderfox : can we put an example.py in 2.0 that just prints "you're a fucking retard"
# invisiblek wuz here
# balthemel wuz also 'ere

# dont make pr to fix pls

print("Please refer to documentation, there is no more example.py, only runserver.py")
fuck = raw_input("Would yous till like to massage the devs that example.py no work?")
if "needful" in fuck.lower():
    print("poon bang lure pls")
elif fuck.lower() == "india":
    print("bang lure?")
elif fuck.lower() != "no":
    print("you have been banned lol")
else:
    print("bless u")
