#!/usr/bin/python
# -*- coding: utf-8 -*-

#Check for needed module, otherwise install 
from pushover_alarm import Pushover_Alarm