#!/usr/bin/python
# -*- coding: utf-8 -*-

config = {
    'LOCALE': 'en',
    'LOCALES_DIR': 'static/dist/locales',
    'ROOT_PATH': '',
    'DATA_DIR': 'static/dist/data',
    'GMAPS_KEY': None
}
