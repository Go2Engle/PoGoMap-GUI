class APIKeyException(Exception):
    pass
